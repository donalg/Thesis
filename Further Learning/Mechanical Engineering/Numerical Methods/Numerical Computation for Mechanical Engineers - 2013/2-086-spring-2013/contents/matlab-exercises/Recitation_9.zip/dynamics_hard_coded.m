function [x_dot] = dynamics_hard_coded(t,x)

k=1;
A=0;
omega=1;
m=1;

F=A*cos(omega*t);

x_dot(1,1)= x(2);
x_dot(2,1)= -k/m*x(1)+F/m;

end