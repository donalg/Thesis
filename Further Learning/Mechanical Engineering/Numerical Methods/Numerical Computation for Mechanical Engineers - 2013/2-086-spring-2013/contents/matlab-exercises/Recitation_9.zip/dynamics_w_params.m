function [x_dot] = dynamics_w_params(t,x,k,A,omega,m)


F=A*cos(omega*t);

x_dot(1,1)= x(2);
x_dot(2,1)= -k/m*x(1)+F/m;

end