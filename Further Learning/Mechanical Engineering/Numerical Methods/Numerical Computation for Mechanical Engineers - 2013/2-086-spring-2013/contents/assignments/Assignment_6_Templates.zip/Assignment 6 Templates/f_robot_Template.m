function [ f  ] = f_robot( q, X )

L1 = 4.0; L2 = 3.025;

end

