function [ Q_ws, X_ws ] = workspace_robot( M )

end




