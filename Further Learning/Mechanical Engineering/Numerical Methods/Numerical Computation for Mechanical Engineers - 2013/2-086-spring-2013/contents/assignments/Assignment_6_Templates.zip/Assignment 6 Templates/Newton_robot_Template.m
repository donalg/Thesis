function [Q_X_hat,exitflag] = Newton_robot(X,Q_ws,X_ws,Newton_tol,num_iter_max)


end

