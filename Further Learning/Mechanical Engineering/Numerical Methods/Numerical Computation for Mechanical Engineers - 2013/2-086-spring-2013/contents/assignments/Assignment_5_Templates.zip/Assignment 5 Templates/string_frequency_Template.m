function [ B, omega_min, chi_1, num_iter ] = ...
    string_frequency(tau,eta,L,n,epsilon,chi_init,lam_init)



end

