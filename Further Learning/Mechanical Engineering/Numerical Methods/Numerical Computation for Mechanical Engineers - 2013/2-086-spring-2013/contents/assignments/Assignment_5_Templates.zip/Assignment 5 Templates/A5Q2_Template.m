multiple_choice_selection = {'?','?','?','?'};
% make sure to use lower-case letters