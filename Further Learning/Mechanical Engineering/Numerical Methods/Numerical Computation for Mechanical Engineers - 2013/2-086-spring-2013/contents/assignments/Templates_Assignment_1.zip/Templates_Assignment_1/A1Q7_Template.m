% note x_vec and x must be assigned outside the script
% recall x_vec points not necessarily equi-distant

ind_less_than = find( ? );

i_star = ?(ind_less_than); 


