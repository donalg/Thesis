% note Nfib must be assigned outside the script 

if (Nfib == 1)
    F_Nfib = 1;
elseif (Nfib == 2)
    F_Nfib = ?;
else
    F_n_2 = 1; % F_{n-2} for n = 3
    F_n_1 = 1; % F_{n-1} for n = 3
    for n = 3:Nfib
        
        F_n = ?; % F_n
        
        % prepare for n+1: shift (or "shuffle")
        F_n_2 = ?;
        F_n_1 = ?;
        
    end
    F_Nfib = ?;
end


    