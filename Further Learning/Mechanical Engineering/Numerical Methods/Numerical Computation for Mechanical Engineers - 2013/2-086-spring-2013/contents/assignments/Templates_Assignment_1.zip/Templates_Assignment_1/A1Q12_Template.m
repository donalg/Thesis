multiple_choice_selection = {'?','?','?'};
% Instructions: replace the first question mark with a single letter which
% is your choice for part (i); replace the second question mark with a
% single letter which is your choice for part (ii);...
% For example: if your choices are "a" for each part, then
% muliple_choice_selection = {'a','a','a'};
% note you must use the single-quote marks around each letter