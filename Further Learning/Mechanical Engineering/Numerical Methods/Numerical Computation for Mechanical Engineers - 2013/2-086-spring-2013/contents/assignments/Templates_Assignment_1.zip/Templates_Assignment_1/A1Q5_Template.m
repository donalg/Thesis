% note F_upper_limit must be assigned outside the script

Ffib_star = [1]; % F_1 is less than F_upper_limit (which must be >=2)

F_n_1 = 1; % F_2
while F_n_1 <= ?
    Ffib_star = [Ffib_star,?];
    
    F_n = Ffib_star(?) + Ffib_star(?); 
    
    F_n_1 = F_n;     
end

