% x_vec, f_vec, and x must be assigned outside the script

A1Q7 % you may directly include one script in another script

% the below just corrects for x = x_N (understandable but incorrect input)
if(i_star == length(x_vec))
    i_star = i_star - 1; 
end

Interp_f_h = ?;



