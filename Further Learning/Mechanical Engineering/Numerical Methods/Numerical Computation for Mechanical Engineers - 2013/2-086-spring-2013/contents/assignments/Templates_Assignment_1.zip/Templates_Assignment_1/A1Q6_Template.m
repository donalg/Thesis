% note Ngeo and rgeo must be provided outside the script


r_vec = rgeo*ones(1,?);
power_vec = ?;
G_Ngeo = sum(?);

