x_vec = linspace(-1,1,100);
