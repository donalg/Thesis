% the script inputs (three in total) are F_fstaticmaxmeas and F_normalload and A_surface


% the script outputs (six in total) are beta_hat_0 and beta_hat_1
%        and beta_hat_2 and I_joint_0 and I_joint_1 and I_joint_2


