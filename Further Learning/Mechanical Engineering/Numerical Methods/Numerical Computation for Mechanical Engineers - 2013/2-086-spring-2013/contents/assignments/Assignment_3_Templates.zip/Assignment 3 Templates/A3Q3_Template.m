% the two script inputs are m and beta_cand


% the two script outputs are beta_hat and delta
