% Note you should not change this script OR run this script.
% If you do happen to look at this script: here f_source is actually the handle
% to f_source (we should have used the name "f_source_handle" for this
% argument rather than "f_source" --- apologies).

[ u_vec ] = Euler_Backward(u_0,lambda,f_source,t_final,J);