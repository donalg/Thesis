a = 1; b = 10; c = 15; M = 55;
I_1 = ?
I_2 = ?
I_3 = ?


% must compute lam_imag_max_1, lam_imag_max_2, lam_imag_max_3, and also
% stability_equi_1, stability_equi_2, stability_equi_3





