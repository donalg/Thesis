multiple_choice_selection = {'?','?','?'};
% must use lower case letters