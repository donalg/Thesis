function [ g_val ] = g_dyn_Q2( t, w, b, alpha )
g_val = zeros(2,1);
g_val(1) = ?
g_val(2) = ?
return
end

