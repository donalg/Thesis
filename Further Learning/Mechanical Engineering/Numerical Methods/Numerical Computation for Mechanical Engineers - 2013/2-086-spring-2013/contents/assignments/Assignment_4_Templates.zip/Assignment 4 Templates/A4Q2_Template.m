

options = odeset('AbsTol',max_err_tol); % tolerance for error
[t_vec,u_approx_vec] = ...
           ode45(?,?,?,options);
 

X_at_t_final = ?

% also must compute t_wall

?
