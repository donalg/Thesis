function [ xpts_pos ] = positive_normal( mu, sigma, n )

xpts_pos = mu + sigma*randn(1,n);

ind_good = find(xpts_pos > 0);
num_to_fix = n - length(ind_good);
xpts_pos = xpts_pos(ind_good);

while ?
    ?
    ?
    ?
    ?
    ?
end
    
    

end

