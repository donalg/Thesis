function [ variates_vec ] = prob_mass_Q3( n )
% can use randi to generate sample of size n and then "map" values appropriately

unif_var = randi(10,1,n);

ind_for_0 = find( unif_var <= 4 );
ind_for_1 = ?;
ind_for_2 = ?;

variates_vec = zeros(1,n);
?
?
?


end

