function [ area_est, area_conf_int ] = MC_area( alpha,c,n,x1pts,x2pts )

?
?
?
?
?
?
?
?

end

