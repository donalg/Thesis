function [ zpts ] = unif_over_sym_int( c,n )
% can use rand

unif = rand(1,n);

zpts = ?;

end

