multiple_choice_selection = {'?','?'};
% replace first ? with the letter of the answer you selected for part (i),
% and similarly for the second ? and part (ii)