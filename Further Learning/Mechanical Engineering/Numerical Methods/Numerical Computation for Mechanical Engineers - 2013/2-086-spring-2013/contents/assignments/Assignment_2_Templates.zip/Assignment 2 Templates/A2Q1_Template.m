% set script input --- array M --- outside of script
% avoid "for" loops as much as possible



% bigsum is the script output