%% 2.086 Recitation 4 - Functions and Random Sampling
% Function material based on Chapter 6 in text.
% Random sampling material based on Chapter 9 in text.
%  Spring 2013 - modified by A Valenzuela

% Uses of functions:  repetion and encapsulation
% Basics of functions:
% Creating functions 
% Saving functions (naming, etc)

%% Example 1 - Simply Returning a Value

x=return_x();

%% Example 2 - Inputting Values / Outputting Values
b=20;

output = double_b(b);

%% Example 3 - What happens in a function stays in a function

a=10;
b=20;

output = triple_b(b);

%% Example 4 - Triple a and b
% Multiple inputs and outputs
a=20;
b=30;

[output_1,output_2] = triple_a_and_b(a,b);

% Two outputs but use the first one in line
result = 2*triple_a_and_b(a,b)


%% Probability

% Generating random numbers
random_numbers = rand(1,10)

% Uniform to Non-Uniform RV's
non_uniform_random = -5+10*rand(1,10)

% Generate Random Integers
random_integer_vector = randi(10,1,5)

%% Many Other Functions Relevant to Probability
% Binomial Distribution
X=5;
N=10;
P=1/2;
binomial_probability = binopdf(X,N,P)

% Normal Distribution
rv_1=randn(10,1)

% Scaling Normal Random Variables
mu=10;
sigma=5;

rv_2 = mu + sigma.*randn(10,1)










