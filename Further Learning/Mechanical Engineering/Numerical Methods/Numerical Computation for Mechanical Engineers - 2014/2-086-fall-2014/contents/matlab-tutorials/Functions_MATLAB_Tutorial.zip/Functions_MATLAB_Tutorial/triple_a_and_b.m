function [result1,result2] = triple_a_and_b(A,B)

result1=3*A;
result2=3*B;


end