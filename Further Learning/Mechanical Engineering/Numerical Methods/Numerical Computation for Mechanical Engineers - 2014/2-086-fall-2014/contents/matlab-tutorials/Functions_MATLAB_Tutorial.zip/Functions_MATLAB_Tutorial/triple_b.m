function return_value=triple_b(b)

%Reassigning a in the function does not change its value in the main
%program
a=50

%Likewise, c will NOT appear in the workspace after running this function
c=100

return_value=3*b;

end 