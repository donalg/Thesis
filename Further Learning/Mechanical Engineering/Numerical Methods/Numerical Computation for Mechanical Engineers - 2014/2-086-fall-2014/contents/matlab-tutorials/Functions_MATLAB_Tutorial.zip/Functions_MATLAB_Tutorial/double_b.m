function return_value=double_b(B)

return_value=2*B;

end 