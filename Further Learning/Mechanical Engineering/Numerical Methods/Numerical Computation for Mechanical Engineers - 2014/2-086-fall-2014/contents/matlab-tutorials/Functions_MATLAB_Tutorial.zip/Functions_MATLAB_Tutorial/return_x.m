function x=return_x()

x=5;

end 