%% first load all the data
clear all
[p,pWithWalks,trueRuns] = process2014Data;
NTeams = size(p,1);

%% simulate things with rudimentary advancement rules, no walks
predRuns = zeros(NTeams,1);
NGames = 1000;
for ii = 1:NTeams
    fprintf('Simulating team %i of %i\n',ii,NTeams);
    roster = repmat(p(ii,:),9,1);
    runs_ii = baseball_game(roster,NGames);
    predRuns(ii) = mean(runs_ii) * 162; %162 games in season
end
%% plot results with rudimentary advancement rules, no walks
figure(1), clf
plot(trueRuns,predRuns,'.','MarkerSize',20);
hold on
x = linspace(min(trueRuns),max(trueRuns));
plot(x,x,'r','LineWidth',2)
axis tight, grid on
xlabel('Runs Scored','FontSize',16)
ylabel('Predicted Runs Scored','FontSize',16)
title('Simple Baserunning Rules','FontSize',16)
legend('Data','True = Predicted','Location','NorthWest')
set(gca,'FontSize',12)
set(gcf, 'PaperPositionMode', 'auto');
print -dpng -r600 baseballSimulator

figure(2), clf
plot(trueRuns,100*(predRuns-trueRuns)./trueRuns,'.','MarkerSize',20)
xlabel('True Runs Scored','FontSize',16)
ylabel('% Error in Prediction','FontSize',16)
title('Simple Baserunning Rules','FontSize',16)
axis tight, grid on
set(gcf, 'PaperPositionMode', 'auto')
print -dpng -r600 baseballSimulator_residuals

