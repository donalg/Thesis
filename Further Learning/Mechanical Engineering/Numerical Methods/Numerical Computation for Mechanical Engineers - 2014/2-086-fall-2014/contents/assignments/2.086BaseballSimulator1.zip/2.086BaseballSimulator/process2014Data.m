function [p,pWithWalks,trueRuns] = process2014Data

%data from http://espn.go.com/mlb/stats/team/_/stat/batting/seasontype/2
% and http://espn.go.com/mlb/stats/team/_/stat/batting/seasontype/2/type/expanded
%dont worry if you don't understand this code

z = load('data/teamData.txt');
z2 = load('data/teamData2.txt');
NTeams = size(z,1);

pWithWalks = zeros(NTeams,6);
trueRuns = zeros(NTeams,1);
for ii = 1:NTeams
    AB = z(ii,2);
    H = z(ii,4);
    doubles = z(ii,5);
    triples = z(ii,6);
    homers = z(ii,7);
    singles = H - doubles - triples - homers;
    bb = z2(ii,2);
    hbp = z2(ii,3);
    ibb = z2(ii,4);
    freePasses = bb + hbp + ibb;  
    NPA = AB + freePasses;
    pWithWalks(ii,2) = singles/ NPA;
    pWithWalks(ii,3) = doubles / NPA;
    pWithWalks(ii,4) = triples / NPA;
    pWithWalks(ii,5) = homers / NPA;
    pWithWalks(ii,6) = freePasses / NPA;
    pWithWalks(ii,1) = 1 - sum(pWithWalks(ii,2:end));
    trueRuns(ii) = z(ii,3);
end

p = zeros(NTeams,5);
p(:,1:5) = pWithWalks(:,1:5);
p(:,2) = p(:,2) + pWithWalks(:,end); %just count walks as singles