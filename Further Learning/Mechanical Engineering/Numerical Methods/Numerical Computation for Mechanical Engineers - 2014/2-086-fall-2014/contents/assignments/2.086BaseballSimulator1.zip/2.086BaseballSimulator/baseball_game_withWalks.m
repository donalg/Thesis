
function [runs_vec] = baseball_game_withWalks(roster,num_games)

% Copyright MIT 2014
% Will Cousins & Tony Patera
% MechE subject 2.086 Fall 2014


%simulate a baseball game with semi-realistic runner advancement rules
%INPUTS
%   roster - 9x6 matrix, where roster(i,j) is probability of batter i
%   obtaining outcome j
%       j = 0 -> Out
%       j = 1 -> Single
%       j = 2 -> Double
%       j = 3 -> Triple
%       j = 4 -> Home Run
%       j = 5 -> Walk
%   num_games - integer number of games you'd like to simulate

if size(roster,2) ~= 6
    error(['You must give 6 probabilities for your players. P of out, single,',...
        'double,triple,home run, and walk']);
end

n = 100*num_games;

hit_sample = zeros(9,n);
for i = 1:9;
    hit_sample(i,:) = base_attained_Q4(roster(i,:),n); % pre-generate hits for all 9 players
end

runs_vec = zeros(1,num_games);
at_bat_counter = ones(1,9); % keep track of random variate for each player

for i_game = 1:num_games;

runs = 0;
up_current = 1; % keep track of batter currently up

for inning = 1:9
    outs = 0;
    on_bases = false(1,3);  % keep track of which bases are occupied 
    % initialize each inning
    
    while (outs < 3)


        hit_current = hit_sample(up_current,at_bat_counter(up_current)); % get current hit
        at_bat_counter(up_current) = at_bat_counter(up_current) + 1; % increment random variate counter for player currently up
        up_current = mod(up_current,9) + 1; % set up_current to next batter in line-up
        
        if(hit_current>0) % if a hit...
            on_bases_new = false(1,7); % expand on_bases array
            if hit_current == 5 %hit_current == 5 is a walk
                %special advancement rules for walks. runner only advances
                %if forced to.  example: runner on first, batter walks,
                %then runner on first advances to second. if runner only on
                %second, batter walks, then runner on second remains on
                %second
                forced = false(1,3);
                for i = 1:3 %check 1st, 2nd, and 3rd base
                    if on_bases(i) && (sum(on_bases(1:i)) == i)
                        forced(i) = true;
                    end
                end

                %advance runners on base who are forced
                on_bases_new(find(forced) + 1) = true;
                
                %if runner is not forced, stays put
                on_bases_new(on_bases & ~forced) = true;
                
                %batter who walks goes to first
                on_bases_new(1) = true;
                runs = runs + sum(on_bases_new(4:7));
                on_bases = on_bases_new(1:3);
            else %batter hits a single, double, or triple
                on_bases_new( find(on_bases) + hit_current ) = true; % advance players
                % assume simplistically that all batters advance hit_current bases
            
                on_bases_new(hit_current) = true; % put up_current player on base
                runs = runs + sum(on_bases_new(4:7)==true); % record runs
                on_bases = on_bases_new(1:3); % save runners on base
                
                %check 2 special cases
                %first, when a single is hit with a runner on second, the
                %runner initially on second could (1) stop at third (2)
                %score or (3) get thrown out attempting to score. Also, when a double
                %is hit with a runner on first, the runner could stop at third/score/
                %get thrown out trying to score. we
                %simulate each of these possible outcomes via real data from
                %baseball-reference.com
                if (hit_current == 1) && on_bases(3) %single, runner initially on second
                    ps2Advance = [0.3608,0.5947,1-.3608-.5947];
                    %ps2Advance = [p(stop at third), p(score),p(out at
                    %home)];
                    s2Advance = rand;
                    if s2Advance < ps2Advance(1)
                        %runner stays put at third. do nothing (remember we
                        %already advanced him in above lines of code)
                    elseif s2Advance < (ps2Advance(1) + ps2Advance(2))
                        %runner scores
                        on_bases(3) = false; %take him off the bases
                        runs = runs + 1; %+1 run
                    else
                        %runner thrown out at home
                        on_bases(3) = false; %take him off the bases
                        outs = outs + 1; %increment outs
                    end
                elseif (hit_current == 2) && on_bases(3) %double, runner INITIALLY on first
                    pd1Advance = [0.5544,0.4158,1-0.5544-0.4158];
                    %pd1Advance = [p(stay at third), p(score), p(thrown out
                    %trying to score)]
                    d1Advance = rand;
                    if d1Advance < pd1Advance(1)
                        %runner stays put. do nothing (remember we already
                        %advanced runner who started at first to third)
                    elseif d1Advance < (pd1Advance(1) + pd1Advance(2))
                        %runner scores
                        on_bases(3) = false;
                        runs = runs + 1;
                    else
                        %runner thrown out at home
                        on_bases(3) = false;
                        outs = outs + 1;
                    end
                end
            end
        else % if an out...
            outs = outs + 1; 
        end
        
    end  
end


runs_vec(i_game) = runs;
end
        
        

