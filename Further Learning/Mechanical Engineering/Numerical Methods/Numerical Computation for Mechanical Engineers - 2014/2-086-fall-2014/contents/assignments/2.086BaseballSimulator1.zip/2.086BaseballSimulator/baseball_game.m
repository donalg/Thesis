
function [runs_vec] = baseball_game(roster,num_games)

% Copyright MIT 2014
% Will Cousins & Tony Patera
% MechE subject 2.086 Fall 2014

%simulate a baseball game with rudimentary baserunner advancement rules
%INPUTS
%   roster - 9x5 matrix, where roster(i,j) is probability of batter i
%   obtaining outcome j
%       j = 0 -> Out
%       j = 1 -> Single
%       j = 2 -> Double
%       j = 3 -> Triple
%       j = 4 -> Home Run
%   num_games - integer number of games you'd like to simulate

n = 100*num_games;

hit_sample = zeros(9,n);
for i = 1:9;
    hit_sample(i,:) = base_attained_Q4(roster(i,:),n); % pre-generate hits for all 9 players
end

runs_vec = zeros(1,num_games);
at_bat_counter = ones(1,9); % keep track of random variate for each player

for i_game = 1:num_games;

runs = 0;
up_current = 1; % keep track of batter currently up

for inning = 1:9
    outs = 0;
    on_bases = false(1,3);  % keep track of which bases are occupied 
    % initialize each inning
    
    while (outs < 3)
        hit_current = hit_sample(up_current,at_bat_counter(up_current)); % get current hit
        at_bat_counter(up_current) = at_bat_counter(up_current) + 1; % increment random variate counter for player currently up
        up_current = mod(up_current-1,9) + 1; % set up_current to next batter in line-up
        
        if(hit_current>0) % if a hit...
            on_bases_new = false(1,7); % expand on_bases array
            on_bases_new( find(on_bases) + hit_current ) = true; % advance players
            % assume simplistically that all batters advance hit_current bases
            
            on_bases_new(hit_current) = true; % put up_current player on base
            runs = runs + sum(on_bases_new(4:7)==true); % record runs
            on_bases = on_bases_new(1:3); % save runners on base
        else % if an out...
            outs = outs + 1; 
        end
        
    end
  
end


runs_vec(i_game) = runs;
end
        
        

