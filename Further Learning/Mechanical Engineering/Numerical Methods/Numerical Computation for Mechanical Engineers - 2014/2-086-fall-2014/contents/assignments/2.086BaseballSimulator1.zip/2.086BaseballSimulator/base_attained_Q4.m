function [ b_variates_vec ] = base_attained_Q4( p_vec, n )

rvarray = cumsum(p_vec);

unif = rand(1,n);
numbases = zeros(1,n);

inds = find(unif<=rvarray(1));
numbases(inds) = zeros(1,length(inds));
for j = 1:length(p_vec)-1;
    inds = find(unif>rvarray(j) & unif<=rvarray(j+1));
    numbases(inds) = j*ones(1,length(inds));
end

b_variates_vec = numbases;

end

