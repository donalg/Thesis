
x_vec = linspace(-1,1,10);

%Write the code to calculate a vector containing the value of each of
%the functions at the points x_vec.  For example, you might say f1=exp(-x_vec)
%In the future, the templates may or may not contain hints when you need to add
%your own code



%Now plot the functions
