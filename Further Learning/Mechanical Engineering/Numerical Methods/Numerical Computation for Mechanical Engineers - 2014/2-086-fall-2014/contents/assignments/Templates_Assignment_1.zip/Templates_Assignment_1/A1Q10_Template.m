% x_vec and f_vec must be assigned outside the script
% recall x_vec points not necessarily equi-distant

N = length(x_vec);

fprime_h_vec = zeros(1,N-1);
fprime_h_vec = ( f_vec([2:N]) - ? )./( ? );

xneg_fprime_h_vec = x_vec( ? );

