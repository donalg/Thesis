% note Nfib must be assigned outside the script

Ffib = zeros(1,Nfib);
Ffib(1) = ?;
Ffib(2) = ?;

for n = 3:Nfib
    Ffib(n) = ?;
end



    