% note F_upper_limit must be assigned outside the script 


F_n_2 = 1; % F_1 (= F_{n-2} for n = 3)
N_star_tmp = 1; % F_1 is less than F_upper_limit (which must be >=2)

F_n_1 = 1; % F_2 (= F_{n-1} for n = 3)
while F_n_1 <= ? 
    N_star_tmp = ?; 
    
    F_n = ?; % F_n
    
    % prepare for n+1: shift (or "shuffle")
    F_n_2 = ?;
    F_n_1 = ?;
   
    
end
    
N_star = ?;

    