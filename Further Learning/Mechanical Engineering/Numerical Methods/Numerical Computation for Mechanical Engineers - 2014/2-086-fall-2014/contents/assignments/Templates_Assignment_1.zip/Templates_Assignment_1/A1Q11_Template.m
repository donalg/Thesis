% x_vec and f_vec must be assigned outside the script
% recall x_vec points not necessarily equi-distant

N = length(x_vec);

Integral_f_h = sum( ( ? ) ? ( ? ) );

