% note that V and D_meas are assigned outside your script
% (either by you, to test your code yourself, or by grade_o_matic)


% you must assign C_hat and gamma_hat inside your script