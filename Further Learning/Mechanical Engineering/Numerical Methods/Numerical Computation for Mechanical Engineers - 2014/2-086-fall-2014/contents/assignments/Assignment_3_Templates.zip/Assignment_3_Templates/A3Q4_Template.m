
% note that Mon_grades, Wed_grades, and Fri_grades are assigned outside 
% your script (either by you, to test your code yourself, or by grade_o_matic)


% you must assign ci_beta_1 and no_unfair_advantage inside your script


% Note shift in indices of beta_hat from theory to Matlab, and
% shift in indices of X (second index) from theory to Matlab;
% in both cases, theory starts from 0, whereas Matlab starts from 1.


% tinv(0.975,m-n) should prove useful