function [ accel_fd, accel_fit ] = accel_calc( time_vec, z_meas_vec )

% time_vec and z_meas_vec are inputs to the function
% and should not be modified in the body of your function


% you must assign values to accel_fd and accel_fit in the body of your function

end

