[accel_fd, accel_fit] = accel_calc(time_vec, z_meas_vec);
% Do not modify this script: remove _Templates in the filename
% and upload in your YOURNAME_ASSIGNMENT_3 folder.