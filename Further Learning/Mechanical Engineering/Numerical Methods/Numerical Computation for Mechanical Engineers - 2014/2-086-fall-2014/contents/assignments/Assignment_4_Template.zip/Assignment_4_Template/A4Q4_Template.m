% set alpha, w_0, t_final outside script


options = odeset('AbsTol',1e-7);
% this line should not be modified and should appear before your call to ode23s

[t_vec,w_vec] = ?;


Z_at_t_final = ?; % assign final position


% Uncomment the below if you wish to print the output.
% fprintf('In script A4Q4, Z_at_t_final = %d.\n',Z_at_t_final);