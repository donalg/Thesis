function [ u_vec ] = Euler_Backward(u_0,lambda,f_source,t_final,J)

Delta_t = ?;

u_vec = zeros(J+1,1);
u_vec(1) = ?;  % set initial condition

% any other preparations, as needed

for j = 2:J+1
    
    % body of update loop
    
end


end

