function [ I_h ] = rect_right_rule(integrand_func,x_min,x_max,N)




end

