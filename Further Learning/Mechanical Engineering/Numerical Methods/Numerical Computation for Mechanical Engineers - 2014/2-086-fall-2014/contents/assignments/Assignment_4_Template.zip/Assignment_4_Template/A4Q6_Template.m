% set a, b, c, and M outside script


G_1 = ?;

G_2 = ?;

G_3 = ?;






