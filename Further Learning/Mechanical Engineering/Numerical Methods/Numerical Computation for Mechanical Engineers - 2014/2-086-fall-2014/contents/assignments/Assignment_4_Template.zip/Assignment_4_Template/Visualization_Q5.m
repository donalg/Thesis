if(exist('w_vec'))


if(strcmp(func2str(Flowfield),'@(x,y)Cylinder_PF(x,y)'))

figure
htemp = plot(w_vec(:,1),w_vec(:,3),'bo'); 
hold on;
rectangle('Position',[-1,-1,2,2],'Curvature',[1,1],'FaceColor','r')
plot(0,0,'r.','MarkerSize',30)
axis equal
xlabel('x'); ylabel('y'); title('trajectory of particle in cylinder potential flow');
legend('particle position','cylinder')

flowvizQ5(Flowfield);


elseif(strcmp(func2str(Flowfield),'@(x,y)Cyclone_PF(x,y)'))
    
figure
plot(w_vec(:,1),w_vec(:,3),'bo')
hold on
rectangle('Position',[-.1,-.1,.2,.2],'Curvature',[1,1],'FaceColor','r')
plot(0,0,'r.','MarkerSize',30)
axis equal
xlabel('x'); ylabel('y'); title('trajectory of particle in cyclone potential flow');
legend('particle position','center of vortex')

flowvizQ5(Flowfield);

else
    
figure
plot(w_vec(:,1),w_vec(:,3),'bo')
axis equal
xlabel('x'); ylabel('y'); title('trajectory of particle in flow');
legend('particle position')

flowvizQ5(Flowfield);

end

else
    
fprintf('No visualization possible: w_vec not defined.\n')

end