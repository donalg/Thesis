function [ w_dot ] = g_particle_in_flow(t, w, alpha, Flowfield )

V = ?; % calculate fluid flow velocity at current particle location

% calculate modulus of (particle - fluid) velocity

w_dot = zeros(4,1);

w_dot(1) = ?;
w_dot(2) = ?;
w_dot(3) = ?;
w_dot(4) = ?;



end

