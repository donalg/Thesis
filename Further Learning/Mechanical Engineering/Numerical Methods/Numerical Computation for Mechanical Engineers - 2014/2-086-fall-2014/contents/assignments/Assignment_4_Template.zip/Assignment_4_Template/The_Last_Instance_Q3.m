clear all

g_grav = 9.81;

alpha = 0.0444;
w_0 = [1.997;-0.428];
t_final = 0.6;

A4Q3
figure
load Falling_Ball_Data
plot(time_full,z_meas_full,'mo');
hold on
plot(time_full,w_0(1) + w_0(2)*time_full - .5*g_grav*(time_full.^2),'kx')

if(exist('t_vec') & exist('w_vec')) 
    plot(t_vec,w_vec(:,1),'b-');
    plot(0.6,Z_at_t_final,'r*');
    leg = legend('experimental measurements','simulation: drag neglected','simulation: drag included','Z_at_t_final: drag included');
else
    fprintf('Limited visualization: t_vec or w_vec not defined.\n')
    plot(0.6,Z_at_t_final,'r*');
    leg = legend('experimental measurements','simulation: drag neglected','Z_at_t_final: drag included');
end

xlabel('time'); ylabel('height');
title('falling ball: simulation vs experiment');
set(leg,'Interpreter','none');
