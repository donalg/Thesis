function [ g_val ] = g_falling_ball(t, w, alpha )


g_val = zeros(2,1);
g_val(1) = ?;
g_val(2) = ?;


end

