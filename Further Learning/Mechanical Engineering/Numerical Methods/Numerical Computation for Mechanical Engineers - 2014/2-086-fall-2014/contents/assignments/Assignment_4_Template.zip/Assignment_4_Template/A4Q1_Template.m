[I_h] = rect_right_rule(integrand_func,x_min,x_max,N);
% Do not modify this script, unless you wish to print out the output,
% in which case you should un-comment the below (but please re-comment
% before submission).

% fprintf('In script A4Q1, I_h = %d.\n',I_h);