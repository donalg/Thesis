function [ Vel_Vect ] = Cyclone_PF( x,y )

m = 10; Gamma = 4;

r = sqrt(x.^2 + y.^2);

cos_th = x./r;
sin_th = y./r;
Vr = -m./(2*pi*r);
Vth = Gamma./(2*pi*r);
Vel_Vect = [Vr.*cos_th - Vth.*sin_th, Vr.*sin_th + Vth.*cos_th];


end

