[u_vec] = Euler_Backward(u_0,lambda,f_source,t_final,J);

% Do not modify this script, unless you wish to plot the solution, in which
% case you should uncomment the below (but please re-comment before
% submission).

% t_vec = linspace(0,t_final,J+1)';
% figure
% plot(t_vec,u_vec,'b-')
% title('In script A4Q2: solution versus time.')