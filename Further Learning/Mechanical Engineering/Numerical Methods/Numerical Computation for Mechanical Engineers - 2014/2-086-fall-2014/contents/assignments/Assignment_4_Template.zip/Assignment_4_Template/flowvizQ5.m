function flowvizQ5(flowfun)
ax0 = axis;
switch func2str(flowfun)
 case 'Cylinder_PF'
  xl = [-5,5];
  yl = [-5,5];
  ns = 20;
  xs = xl(1)*ones(ns,1);
  ys = linspace(yl(1),yl(2),ns)';
 case 'Cyclone_PF' 
  rl = 5;
  xl = [-rl,rl];
  yl = [-rl,rl];
  nt = 25;
  xs = rl*cos(linspace(0,2*pi,nt));
  ys = rl*sin(linspace(0,2*pi,nt));
 otherwise % generic case: seed the boundary
  ns = 10;
  xl = xlim;
  yl = ylim;
  xs = [xl(1)*ones(1,ns),xl(2)*ones(1,ns), ...
        linspace(xl(1),xl(2),ns),linspace(xl(1),xl(2),ns)].';
  ys = [linspace(yl(1),yl(2),ns),linspace(yl(1),yl(2),ns), ...
        yl(1)*ones(1,ns),yl(2)*ones(1,ns)].';
end

nx = 101;
ny = 101;
x = linspace(xl(1),xl(2),nx);
y = linspace(yl(1),yl(2),ny);
[xx,yy] = meshgrid(x,y);
nn = size(xx);
try 
  vvel = flowfun(xx(:),yy(:));
catch err 
  if ( strcmp(err.identifier,'MATLAB:innerdim') | strcmp(err.identifier,'MATLAB:mpower:notScalarAndSquareMatrix') ) % non-vectorization error(s)
    fprintf('\nFlowfield function is not vectorized: resorting to (slow) loop evaluation.\n\n');
    vvel = zeros(length(xx(:)),2);
    for k = 1:length(xx(:))
      vvel(k,:) = flowfun(xx(k),yy(k));
    end
  else % some other error
    rethrow(err);
  end
end
uu = reshape(vvel(:,1),nn);
vv = reshape(vvel(:,2),nn);
h = streamline(xx,yy,uu,vv,xs,ys);
set(h,'color',[0.5,0.5,0.5]);

axis(ax0);
