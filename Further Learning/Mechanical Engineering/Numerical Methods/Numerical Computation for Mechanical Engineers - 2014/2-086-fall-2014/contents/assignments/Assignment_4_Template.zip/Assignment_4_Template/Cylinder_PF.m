function [ Vel_Vect ] = Cylinder_PF( x,y )

r = sqrt(x.^2 + y.^2);
rsq = r.*r;
cos_th = x./r;
sin_th = y./r;
Vr = (1 - (1./rsq)).*cos_th;
Vth = -(1 + (1./rsq)).*sin_th;
Vel_Vect = [Vr.*cos_th - Vth.*sin_th, Vr.*sin_th + Vth.*cos_th];


end

