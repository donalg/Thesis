% fsolve_demo script

clear
close all

func = @(z)-(1 + 2*z.*z - z.^4);

a = -1.8; b = 1.8;
zpts = linspace(a,b,400);
plot(zpts,func(zpts),'b-')
hold on

fsquared = @(z) func(z).*func(z);

plot(zpts,fsquared(zpts),'m--')
[zstarstar_1,fval,exitf]  = fsolve(func,1.2) % call fsolve with initial guess 1.2
[zstarstar_2,fval,exitf] = fsolve(func,0.9) % call fsolve with initial guess 0.9
[zstarstar_3,fval,exitf] = fsolve(func,-1.0 -1e-8) % call fsolve with initial guess -1.0 - 1e-8
[zstarstar_4,fval,exitf] = fsolve(func,-1.0 -1e-4)% call fsolve with initial guess -1.0 - 1e-4
plot(zstarstar_1,fsquared(zstarstar_1),'go','MarkerSize',10);
plot(zstarstar_2,fsquared(zstarstar_2),'gs','MarkerSize',10);
plot(zstarstar_3,fsquared(zstarstar_3),'g^','MarkerSize',10);
plot(zstarstar_4,fsquared(zstarstar_4),'g*','MarkerSize',10);

title('fsolve demonstration')
xlabel('z')
ylabel('function values')
legend('function','function squared','fsolve: initial guess 1.2', 'fsolve: initial guess .9',...
    'fsolve: initial guess -1 - 1e-8','fsolve: initial guess -1 - 1e-4')
axis([-2 2 -4 10])

