function [root] = root_finder(alpha)

% recall that you should use the default values for the fsolve tolerances

end
        
    
    
    
    
    