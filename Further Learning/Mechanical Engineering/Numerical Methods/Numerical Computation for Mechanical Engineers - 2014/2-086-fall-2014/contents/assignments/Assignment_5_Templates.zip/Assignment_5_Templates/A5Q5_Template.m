%You should not modify this script.

root = root_finder(alpha);
f_val_max = 0;

for i = 1:10
    f_valt = abs(f_wiggly(root,alpha));
if( root < 0 | root > 1)
    f_valt = f_valt + 1;
end
f_val_max = max(f_val_max,f_valt);
end

mystery_output = f_val_max;
