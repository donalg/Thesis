#ifndef _DMA_H_
#define _DMA_H_

#include <stdint.h>

typedef uint32_t uintptr32_t;

// Size of each data element
#define ELEMENT_SIZE sizeof(int)

#define MUL_FACTOR 2
#define ADD_FACTOR 10000

// Control block - tells SPU where to get the data from
typedef struct _CONTROL_BLOCK {
  uintptr32_t data_addr;
  uint32_t num_elements;
} CONTROL_BLOCK;

#endif
